package com.ekiras.dao;

import com.ekiras.domain.Person;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by ekansh on 13/7/15.
 */
@Repository
public class PersonDAO {

}
